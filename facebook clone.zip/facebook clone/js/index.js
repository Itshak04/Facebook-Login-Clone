function openForm(el) {
    var popIn = document.getElementById("createForm");
    popIn.style.display = "block";
  }
  
  function closeForm() {
    var popOut = document.getElementById("createForm");
    popOut.style.display = "none";
  }
  